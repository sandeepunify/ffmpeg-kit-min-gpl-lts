#!/bin/bash

BITCODE_STRIP=$(xcrun --find bitcode_strip)

# List of frameworks to strip
FRAMEWORKS=("ffmpegkit" "libavcodec" "libavdevice" "libavfilter" "libavformat" "libavutil" "libswresample" "libswscale")

# Base path to the XCFramework
XCFRAMEWORK_PATH=""

# Strip bitcode for each framework
for FW in "${FRAMEWORKS[@]}"; do
  EXEC_PATH="${FW}.framework/${FW}"
  if [ -f "$EXEC_PATH" ]; then
    echo "Stripping bitcode from $EXEC_PATH"
    $BITCODE_STRIP -r "$EXEC_PATH" -o "$EXEC_PATH"
  else
    echo "Warning: $EXEC_PATH not found, skipping"
  fi
done